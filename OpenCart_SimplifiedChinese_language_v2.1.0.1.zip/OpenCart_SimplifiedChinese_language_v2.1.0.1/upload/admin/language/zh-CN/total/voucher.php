<?php
// Heading
$_['heading_title']    = '礼品券';

// Text
$_['text_total']       = '订单金额';
$_['text_success']     = '成功 您已成功修改礼品券！';
$_['text_edit']        = '编辑礼品券';

// Entry
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告 您没有变更礼品券的权限！';