<?php
$_['text_complete_status']   = '订单已经完成';
$_['text_processing_status'] = '订单待处理';
$_['text_other_status']      = '其它状态';