<?php
// Heading
$_['heading_title']    = '谷歌网站地图';

// Text
$_['text_feed']        = '插件扩展';
$_['text_success']     = '成功： 您已修改谷歌网站地图！';
$_['text_list']        = '布局列表';
$_['text_edit']        = '编辑谷歌地图';

// Entry
$_['entry_status']     = '状态';
$_['entry_data_feed']  = '资料数据网址';

// Error
$_['error_permission'] = '警告： 您没有权限修改谷歌网站地图！';
