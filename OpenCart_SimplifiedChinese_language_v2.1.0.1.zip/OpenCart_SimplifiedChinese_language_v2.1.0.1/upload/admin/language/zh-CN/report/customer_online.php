<?php
// Heading
$_['heading_title']     = '网上客户统计';

// Text
$_['text_list']         = '在线客户列表';
$_['text_guest']        = '游客';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = '顾客';
$_['column_url']        = '最近访问的页面';
$_['column_referer']    = '参考来源';
$_['column_date_added'] = '最后点击日志';
$_['column_action']     = '管理';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = '客户';