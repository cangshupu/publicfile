<?php
// Heading
$_['heading_title']     = '商品购买报表';

// Text
$_['text_list']         = '商品购买列表';
$_['text_all_status']   = '所有状态';

// Column
$_['column_date_start'] = '开始日期';
$_['column_date_end']   = '结束日期';
$_['column_name']       = '商品名称';
$_['column_model']      = '商品型号';
$_['column_quantity']   = '购买数量';
$_['column_total']      = '金额总计';

// Entry
$_['entry_date_start']  = '开始日期';
$_['entry_date_end']    = '结束日期';
$_['entry_status']      = '销售状态';
