<?php
$_['heading_title']    = '基本验证码';

// Text
$_['text_captcha']     = '验证码';
$_['text_success']	   = '成功：您已经修改了基本验证码！';
$_['text_edit']        = '编辑基本验证码';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告：您没有权限修改基本验证码！';
