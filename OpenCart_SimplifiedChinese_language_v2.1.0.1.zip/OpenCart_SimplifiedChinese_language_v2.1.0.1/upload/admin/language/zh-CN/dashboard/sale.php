<?php
// Heading
$_['heading_title'] = '销售总额';

// Text
$_['text_view']     = '显示详细...';