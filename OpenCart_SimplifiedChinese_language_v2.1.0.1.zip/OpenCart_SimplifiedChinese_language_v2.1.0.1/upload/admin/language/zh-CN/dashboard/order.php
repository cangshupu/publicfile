<?php
// Heading
$_['heading_title'] = '总订单数';

// Text
$_['text_view']     = '显示详细...';