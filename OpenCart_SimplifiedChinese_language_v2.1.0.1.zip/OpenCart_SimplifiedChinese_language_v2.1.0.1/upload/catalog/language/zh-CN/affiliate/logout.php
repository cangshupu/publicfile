<?php
// Heading
$_['heading_title'] = '退出账号';

// Text
$_['text_message']  = '<p>您已退出了您的个人账户。</p>';
$_['text_account']  = '账号';
$_['text_logout']   = '退出';