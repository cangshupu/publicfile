<?php
// Heading
$_['heading_title']        = '加盟会员账户';

// Text
$_['text_account']         = '加盟会员账户';
$_['text_my_account']      = '我的加盟会员账户';
$_['text_my_tracking']     = '加盟跟踪信息';
$_['text_my_transactions'] = '我的余额';
$_['text_edit']            = '编辑账户信息';
$_['text_password']        = '更改登录密码';
$_['text_payment']         = '更改支付方式';
$_['text_tracking']        = '用户跟踪号';
$_['text_transaction']     = '查看我的交易记录';