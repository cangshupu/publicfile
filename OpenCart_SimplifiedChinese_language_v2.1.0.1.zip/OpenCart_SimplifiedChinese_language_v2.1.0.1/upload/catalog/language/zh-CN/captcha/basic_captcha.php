<?php
// Heading
$_['heading_title'] = '验证码';

// Entry
$_['entry_captcha'] = '输入方框里的编码';

// Error
$_['error_captcha'] = '输入的编码和图片里面的编码不一致！';
