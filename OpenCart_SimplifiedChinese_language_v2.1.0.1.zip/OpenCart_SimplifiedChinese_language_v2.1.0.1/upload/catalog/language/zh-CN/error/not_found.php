<?php
// Heading
$_['heading_title'] = '您请求的页面不存在！';

// Text
$_['text_error']    = '您所查询的页面不存在！';