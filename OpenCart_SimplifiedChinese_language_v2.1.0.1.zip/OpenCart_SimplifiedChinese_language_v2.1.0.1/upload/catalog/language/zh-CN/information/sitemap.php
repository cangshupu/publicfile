<?php
// Heading
$_['heading_title']    = '网站地图';

// Text
$_['text_special']     = '特别优惠';
$_['text_account']     = '我的账户';
$_['text_edit']        = '账户信息';
$_['text_password']    = '更新密码';
$_['text_address']     = '收货地址';
$_['text_history']     = '订单记录';
$_['text_download']    = '下载商品';
$_['text_cart']        = '购物车';
$_['text_checkout']    = '结账';
$_['text_search']      = '搜索';
$_['text_information'] = '信息中心';
$_['text_contact']     = '联系我们';
