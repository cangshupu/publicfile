<?php
// Text
$_['text_subject']  = '%s - 会员新密码';
$_['text_greeting'] = '我们从 %s 收到您请求新的密码，建议您在使用新密码登入后立即变更此密码，并妥善保存...';
$_['text_password'] = '您的新密码';