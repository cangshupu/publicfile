<?php
$_['text_total'] = '订单总额';