<?php
// Heading
$_['heading_title'] = '使用积分（可用 %s）';

// Text
$_['text_reward']   = '积分(%s)';
$_['text_order_id'] = '订单 ID: #%s';
$_['text_success']  = '成功：您的积分已经使用！';

// Entry
$_['entry_reward']  = '使用积分 (最多 %s)';

// Error
$_['error_reward']  = '警告：请输入您要使用积分数！';
$_['error_points']  = '警告：您没有 %s 积分！';
$_['error_maximum'] = '警告：: 可以应用的最大积分数是 %s!';