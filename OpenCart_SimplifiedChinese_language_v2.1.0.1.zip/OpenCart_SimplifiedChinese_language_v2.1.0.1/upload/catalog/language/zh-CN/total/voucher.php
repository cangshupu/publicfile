<?php
// Heading
$_['heading_title'] = '使用礼品券';

// Text
$_['text_voucher']  = '礼券 (%s)';
$_['text_success']  = '成功：您已经使用礼券折扣！';

// Entry
$_['entry_voucher'] = '输入您的礼券编码';

// Error
$_['error_voucher'] = '警告：礼品券无效或余额已用完!';
$_['error_empty']   = '警告：请输入礼券编码！';