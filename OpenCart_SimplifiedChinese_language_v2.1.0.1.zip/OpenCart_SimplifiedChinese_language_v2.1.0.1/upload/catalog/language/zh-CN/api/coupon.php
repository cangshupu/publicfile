<?php
// Text
$_['text_success']     = '成功：您的优惠券折扣已应用！';

// Error
$_['error_permission'] = '警告：您没有权限访问该API！';
$_['error_coupon']     = '警告：优惠券已无效，过期或达到它的使用限制！';