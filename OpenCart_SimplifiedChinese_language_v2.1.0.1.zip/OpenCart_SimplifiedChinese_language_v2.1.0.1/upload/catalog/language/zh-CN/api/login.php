<?php
// Text
$_['text_success'] = '成功：API会话启动成功！';

// Error
$_['error_key']  = '警告：不正确的API 秘钥！';
$_['error_ip']   = '警告：您的IP %s 不允许访问 API!';