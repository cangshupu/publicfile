<?php
// Text
$_['text_success']     = '成功：您的货币已经转换！';

// Error
$_['error_permission'] = '警告：您还没有权限访问这个API！';
$_['error_currency']   = '警告：货币代码不正确！';