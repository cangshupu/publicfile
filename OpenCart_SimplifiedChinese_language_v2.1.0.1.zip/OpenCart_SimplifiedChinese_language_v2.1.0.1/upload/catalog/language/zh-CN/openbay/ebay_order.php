<?php
// Text
$_['text_total_shipping']		= '货运';
$_['text_total_discount']		= '优惠';
$_['text_total_tax']			= '税';
$_['text_total_sub']			= '小计';
$_['text_total']				= '合计';
$_['text_smp_id']				= '销售管理者ID：';
$_['text_buyer']				= '买家用户姓名：'