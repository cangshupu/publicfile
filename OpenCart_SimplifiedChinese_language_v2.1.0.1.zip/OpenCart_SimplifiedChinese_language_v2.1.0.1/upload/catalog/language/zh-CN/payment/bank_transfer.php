<?php
// Text
$_['text_title']				= '银行转账';
$_['text_instruction']			= '银行转账说明';
$_['text_description']			= '请按照提供的银行账号支付货款';
$_['text_payment']				= '我们收到您支付的货款后才能发货。';