<?php
// Text
$_['text_title']				= 'Cheque / Money Order';
$_['text_instruction']			= 'Cheque / Money Order Instructions';
$_['text_payable']				= 'Make Payable To: ';
$_['text_address']				= 'Send To: ';
$_['text_payment']				= 'Your order will not ship until we receive payment.';