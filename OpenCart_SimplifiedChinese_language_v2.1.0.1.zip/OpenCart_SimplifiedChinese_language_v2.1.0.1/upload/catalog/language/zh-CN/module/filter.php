<?php
// Heading
$_['heading_title'] = '分类搜索';