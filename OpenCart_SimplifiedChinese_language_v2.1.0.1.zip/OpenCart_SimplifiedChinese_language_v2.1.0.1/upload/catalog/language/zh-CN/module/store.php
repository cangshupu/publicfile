<?php
// Heading
$_['heading_title'] = '选择商店';

// Text
$_['text_default']  = '默认';
$_['text_store']    = '请选择您要访问的商店。';