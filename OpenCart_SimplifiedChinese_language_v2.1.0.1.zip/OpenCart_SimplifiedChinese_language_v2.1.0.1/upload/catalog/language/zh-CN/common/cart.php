<?php
// Text
$_['text_items']             = '%s 个商品 - %s';
$_['text_empty']             = '您的购物车内没有商品！';
$_['text_cart']              = '查看购物车';
$_['text_checkout']          = '去结账';
$_['text_recurring']         = '分期付款';