<?php
// Heading
$_['heading_title']      = '我的余额';

// Column
$_['column_date_added']  = '交易日期';
$_['column_description'] = '说明';
$_['column_amount']      = '合计 (%s)';

// Text
$_['text_account']       = '账户';
$_['text_transaction']   = '我的余额';
$_['text_total']         = '我的余额额为';
$_['text_empty']         = '您还没有任何交易记录！';