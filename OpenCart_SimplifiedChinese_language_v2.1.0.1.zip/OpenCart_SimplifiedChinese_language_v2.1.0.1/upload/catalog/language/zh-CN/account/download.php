<?php
// Heading
$_['heading_title']   = '下载文件';

// Text
$_['text_account']    = '我的账户';
$_['text_downloads']  = '下载文件';
$_['text_empty']      = '您没有任何可下载的文件！';

// Column
$_['column_order_id']   = '订单 ID';
$_['column_name']       = '名称';
$_['column_size']       = '大小';
$_['column_date_added'] = '添加时间';