<?php
// Heading
$_['heading_title']      = '我的奖励积分';

// Column
$_['column_date_added']  = '获取日期';
$_['column_description'] = '说明';
$_['column_points']      = '奖励积分数';

// Text
$_['text_account']       = '账户';
$_['text_reward']        = '奖励积分';
$_['text_total']         = '我的奖励积分总数为';
$_['text_empty']         = '您现在还没有获取过奖励积分！';