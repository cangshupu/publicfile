<?php
// Text
$_['text_title']    = '澳大利亚邮政';
$_['text_express']  = '快递';
$_['text_standard'] = '标准';
$_['text_eta']      = '天数';