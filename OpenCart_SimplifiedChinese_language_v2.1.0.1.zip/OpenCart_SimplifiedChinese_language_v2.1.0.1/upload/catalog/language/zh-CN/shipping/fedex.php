<?php
// Text
$_['text_title']                               = '联邦快递';
$_['text_weight']                              = '重量';
$_['text_eta']                                 = '估计时间';
$_['text_europe_first_international_priority'] = '欧洲第一个国际优先';
$_['text_fedex_1_day_freight']                 = '联邦1天货运';
$_['text_fedex_2_day']                         = '联邦2天';
$_['text_fedex_2_day_am']                      = '联邦2天早上';
$_['text_fedex_2_day_freight']                 = '联邦2天晚上';
$_['text_fedex_3_day_freight']                 = '联邦3天晚上';
$_['text_fedex_express_saver']                 = '联邦快递';
$_['text_fedex_first_freight']                 = '联邦第一跳';
$_['text_fedex_freight_economy']               = '联邦航空经济';
$_['text_fedex_freight_priority']              = '联邦航空优先';
$_['text_fedex_ground']                        = '联邦地面';
$_['text_first_overnight']                     = '第一夜';
$_['text_ground_home_delivery']                = '地面送货上门';
$_['text_international_economy']               = '国际经济';
$_['text_international_economy_freight']       = '国际货运';
$_['text_international_first']                 = '国际一级';
$_['text_international_priority']              = '国际优先';
$_['text_international_priority_freight']      = '国际优先货运';
$_['text_priority_overnight']                  = '优先过夜';
$_['text_smart_post']                          = '快捷货运';
$_['text_standard_overnight']                  = '标准过夜';