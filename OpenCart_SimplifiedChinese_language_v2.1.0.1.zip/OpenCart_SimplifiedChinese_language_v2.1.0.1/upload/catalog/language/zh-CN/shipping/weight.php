<?php
// Text
$_['text_title'] = '按重量计算运费';
$_['text_weight'] = '重量'; 