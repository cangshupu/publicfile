<?php
// Text

$_['text_description'] = 'SFC Shipping Rate';
$_['text_estimated'] = 'Delivery Estimated:';
$_['text_days'] = 'days to major destinations';
$_['text_recalculate']       = 'Recalculate';
$_['text_shipping_too']        = 'Courier Cost to:';
$_['text_via']        = 'Deliver via:';