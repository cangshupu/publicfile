OpenCart简体中文语言包 OpenCart V2.1.0.x

版权所有:www.opencart.cn

下载解压后有两个文件夹，admin目录下的语言翻译是后台用的，catalog目录下的语言翻译是前台用的。

-------------------------------------------------------------------------------------------------------------
Name: 	Simplified Chinese Language Pack
Exension Type: 	Languages
License: 	    free
Author: 	    www.openCart.cn
Date Added: 	2016/02/14
Version 	Compatible With v2.1.0.x
-------------------------------------------------------------------------------------------------------------

1、商店后台登入：

选择： System -> Localisation -> Languages -> Insert

填入如下：

Language Name: 简体中文
Code:   zh_CN
Locale: zh_CN.UTF-8,zh_CN,zh-cn,china
Image: cn.png
Directory: zh-CN
Status: Enabled (启动)
Sort Order: 任意数字

填写后按 Save 存档

2、把正体中文设置为预设语言：

选择：Sytem -> Settings -> Local

在下列项目 选择简体中文

Language: 简体中文
Administration Language: 简体中文

填写后按 Save 存档


==================================
opencart中文官方网站www.opencart.cn
==================================

演示地址：
http://demo.opencart.cn  （免费版） 
http://mall.opencart.cn   (专业版)